
```
$ sudo apt-get install python-software-properties
$ curl -sL https://deb.nodesource.com/setup_7.x | sudo -E bash -
$ sudo apt-get update
$ sudo apt-get install build-essential
$ sudo apt-get install nodejs
$ sudo apt-get install npm
```
To run -
```

$ npm install && npm start

-

